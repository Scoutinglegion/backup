<?php

/* 跳转到后台 */
header("Location: ./admin/index.php");
exit;

?>