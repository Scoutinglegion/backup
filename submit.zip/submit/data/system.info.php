<?php
return array (
  'version' => '2.3.0',
  'release' => '20120918',
); 
?>