<?php

return array (
  'cleanup' => 
  array (
    'cycle' => 'custom',
    'interval' => 3600,
    'due_time' => 1348484603,
    'last_time' => 1348481003,
  ),
);

?>