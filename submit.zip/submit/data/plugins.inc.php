<?php

return array (
  'on_run_action' => 
  array (
    'short_store_url' => 
    array (
    ),
  ),
  'after_opening' => 
  array (
    'open_email' => 
    array (
      'subject' => '',
      'content' => '',
    ),
  ),
);

?>