<?php

return array (
  'SITE_URL' => 'http://cnzdzdn.gicp.net',
  'DB_CONFIG' => 'mysql://root:123456@localhost:3306/ecmall1hao',
  'DB_PREFIX' => 'ecm_',
  'LANG' => 'sc-gbk',
  'COOKIE_DOMAIN' => '',
  'COOKIE_PATH' => '/',
  'ECM_KEY' => '9751c3116412a5fb0a604aa015adcdb5',
  'MALL_SITE_ID' => 'EMMJYSDT132KIBHA',
  'ENABLED_GZIP' => 0,
  'DEBUG_MODE' => 0,
  'CACHE_SERVER' => 'default',
  'MEMBER_TYPE' => 'default',
  'ENABLED_SUBDOMAIN' => 0,
  'SUBDOMAIN_SUFFIX' => '',
  'SESSION_TYPE' => 'mysql',
  'SESSION_MEMCACHED' => '',
  'CACHE_MEMCACHED' => '',
);

?>