<?php

return array (
  'widgets' => 
  array (
    '_widget_628' => 
    array (
      'name' => 'advt',
      'options' => 
      array (
        'style' => 'image',
        'url1' => 'ads/1977168.jpg',
        'link2' => 'http://www.psmoban.com',
        'width1' => '980',
        'height1' => '60',
        'alt' => '',
      ),
    ),
    '_widget_895' => 
    array (
      'name' => 'yhd_category',
      'options' => NULL,
    ),
    '_widget_190' => 
    array (
      'name' => 'brand',
      'options' => NULL,
    ),
  ),
  'config' => 
  array (
    'banner2' => 
    array (
      0 => '_widget_628',
    ),
    'right1' => 
    array (
      0 => '_widget_895',
    ),
    'right2' => 
    array (
      0 => '_widget_190',
    ),
  ),
);

?>