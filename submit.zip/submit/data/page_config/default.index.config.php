<?php

return array (
  'widgets' => 
  array (
    '_widget_877' => 
    array (
      'name' => 'notice',
      'options' => 
      array (
        'ad_image_url' => 'data/files/mall/template/200908070207084061.gif',
        'ad_link_url' => '',
      ),
    ),
    '_widget_578' => 
    array (
      'name' => 'register_and_apply',
      'options' => NULL,
    ),
    '_widget_323' => 
    array (
      'name' => 'brand',
      'options' => NULL,
    ),
    '_widget_698' => 
    array (
      'name' => 'cycle_image',
      'options' => 
      array (
        0 => 
        array (
          'ad_image_url' => 'data/files/mall/template/200908070157266315.jpg',
          'ad_link_url' => '',
        ),
        1 => 
        array (
          'ad_image_url' => 'data/files/mall/template/200908070157263175.jpg',
          'ad_link_url' => '',
        ),
        2 => 
        array (
          'ad_image_url' => 'data/files/mall/template/200908070157264923.jpg',
          'ad_link_url' => '',
        ),
      ),
    ),
    '_widget_279' => 
    array (
      'name' => 'sale_price',
      'options' => 
      array (
        'img_recom_id' => '9',
        'img_cate_id' => 0,
        'txt_recom_id' => '10',
        'txt_cate_id' => 0,
      ),
    ),
    '_widget_871' => 
    array (
      'name' => 'best_goods',
      'options' => 
      array (
        'img_recom_id' => '11',
        'img_cate_id' => 0,
      ),
    ),
    '_widget_103' => 
    array (
      'name' => 'four_image_ads',
      'options' => 
      array (
        'ad1_image_url' => 'data/files/mall/template/200908070206301106.gif',
        'ad1_link_url' => '',
        'ad2_image_url' => 'data/files/mall/template/200908070206301621.gif',
        'ad2_link_url' => '',
        'ad3_image_url' => 'data/files/mall/template/200908070206309994.gif',
        'ad3_link_url' => '',
        'ad4_image_url' => 'data/files/mall/template/200908070206302918.gif',
        'ad4_link_url' => '',
      ),
    ),
    '_widget_505' => 
    array (
      'name' => 'image_ad',
      'options' => 
      array (
        'ad_image_url' => 'data/files/mall/template/200908070205218467.gif',
        'ad_link_url' => '',
      ),
    ),
    '_widget_520' => 
    array (
      'name' => 'recommended_store',
      'options' => 
      array (
        'num' => '5',
      ),
    ),
    '_widget_930' => 
    array (
      'name' => 'image_ad',
      'options' => 
      array (
        'ad_image_url' => 'data/files/mall/template/200908070208384344.gif',
        'ad_link_url' => '',
      ),
    ),
    '_widget_904' => 
    array (
      'name' => 'latest_sold',
      'options' => 
      array (
        'num' => '5',
      ),
    ),
    '_widget_598' => 
    array (
      'name' => 'image_ad',
      'options' => 
      array (
        'ad_image_url' => 'data/files/mall/template/200908070208252680.gif',
        'ad_link_url' => '',
      ),
    ),
    '_widget_659' => 
    array (
      'name' => 'sales_list',
      'options' => NULL,
    ),
    '_widget_198' => 
    array (
      'name' => 'goods_module_1',
      'options' => 
      array (
        'module_name' => '�����ϼ�',
        'bgcolor' => '#dcad7f',
        'keyword_list' => '���� ���� ��װ ŮЬ',
        'ad_image_url' => 'data/files/mall/template/200908070210109769.jpg',
        'ad_link_url' => '',
        'img_recom_id' => '12',
        'img_cate_id' => 0,
        'txt_recom_id' => '13',
        'txt_cate_id' => 0,
      ),
    ),
    '_widget_394' => 
    array (
      'name' => 'goods_module_2',
      'options' => 
      array (
        'module_name' => '�˶�����',
        'bgcolor' => '#9fd9dd',
        'keyword_list' => 'nike ����˹���� ���� ����',
        'ad_image_url' => 'data/files/mall/template/200908070210404627.gif',
        'ad_link_url' => '',
        'img_recom_id' => '14',
        'img_cate_id' => 0,
        'sub_module_name' => '�����Ƽ�',
        'txt_recom_id' => '15',
        'txt_cate_id' => 0,
      ),
    ),
    '_widget_436' => 
    array (
      'name' => 'gcategory_list',
      'options' => NULL,
    ),
    '_widget_289' => 
    array (
      'name' => 'partner',
      'options' => NULL,
    ),
  ),
  'config' => 
  array (
    'top_left' => 
    array (
      0 => '_widget_877',
      1 => '_widget_578',
      2 => '_widget_323',
    ),
    'cycle_image' => 
    array (
      0 => '_widget_698',
    ),
    'sales' => 
    array (
      0 => '_widget_279',
    ),
    'top_right' => 
    array (
      0 => '_widget_871',
      1 => '_widget_103',
    ),
    'banner' => 
    array (
      0 => '_widget_505',
    ),
    'bottom_left' => 
    array (
      0 => '_widget_520',
      1 => '_widget_930',
      2 => '_widget_904',
      3 => '_widget_598',
      4 => '_widget_659',
    ),
    'bottom_right' => 
    array (
      0 => '_widget_198',
      1 => '_widget_394',
      2 => '_widget_436',
    ),
    'bottom_down' => 
    array (
      0 => '_widget_289',
    ),
  ),
);

?>