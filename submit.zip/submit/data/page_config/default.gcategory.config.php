<?php

return array (
  'widgets' => 
  array (
    '_widget_249' => 
    array (
      'name' => 'latest_sold',
      'options' => NULL,
    ),
    '_widget_207' => 
    array (
      'name' => 'brand',
      'options' => NULL,
    ),
  ),
  'config' => 
  array (
    'right' => 
    array (
      0 => '_widget_249',
      1 => '_widget_207',
    ),
  ),
);

?>