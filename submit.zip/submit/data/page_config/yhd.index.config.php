<?php

return array (
  'widgets' => 
  array (
    '_widget_847' => 
    array (
      'name' => 'yhd_category',
      'options' => NULL,
    ),
    '_widget_344' => 
    array (
      'name' => 'yhd_groupbuy',
      'options' => 
      array (
        'model_name' => '1����',
        'amount' => '',
      ),
    ),
    '_widget_432' => 
    array (
      'name' => 'advt',
      'options' => 
      array (
        'style' => 'image',
        'url1' => 'ads/1981496.jpg',
        'link2' => 'http://www.psmoban.com',
        'width1' => '765',
        'height1' => '60',
        'alt' => '',
      ),
    ),
    '_widget_746' => 
    array (
      'name' => 'yhd_slides',
      'options' => 
      array (
        0 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107131610449701.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
          'ad_title' => NULL,
        ),
        1 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107131610447979.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
          'ad_title' => NULL,
        ),
        2 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107131610446151.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
          'ad_title' => NULL,
        ),
        3 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107131610443068.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
          'ad_title' => NULL,
        ),
        4 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107131610448213.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
          'ad_title' => NULL,
        ),
        5 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107131610447842.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
          'ad_title' => NULL,
        ),
        6 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107131610443648.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
          'ad_title' => NULL,
        ),
      ),
    ),
    '_widget_936' => 
    array (
      'name' => 'yhd_scroll',
      'options' => 
      array (
        0 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107150400177279.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
        ),
        1 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107150400174406.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
        ),
        2 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107150400176064.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
        ),
        3 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107150400172409.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
        ),
        4 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107150400172611.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
        ),
        5 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107150400179704.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
        ),
        6 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107150400178392.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
        ),
        7 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107150401483256.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
        ),
        8 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107150401488658.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
        ),
        9 => 
        array (
          'ad_image_url' => 'data/files/mall/template/201107150401482773.jpg',
          'ad_link_url' => 'http://www.psmoban.com',
        ),
      ),
    ),
    '_widget_760' => 
    array (
      'name' => 'yhd_recommend',
      'options' => 
      array (
        'cate_name_1' => '��ʱ����',
        'img_recom_id_1' => '15',
        'img_cate_id_1' => '0',
        'cate_name_2' => 'Ʒ�ƾ�ѡ',
        'img_recom_id_2' => '-100',
        'img_cate_id_2' => '21',
        'cate_name_3' => '�����Ƽ�',
        'img_recom_id_3' => '15',
        'img_cate_id_3' => '0',
        'cate_name_4' => '��Ʒ����',
        'img_recom_id_4' => '-100',
        'img_cate_id_4' => '21',
      ),
    ),
    '_widget_217' => 
    array (
      'name' => 'yhd_login',
      'options' => NULL,
    ),
    '_widget_607' => 
    array (
      'name' => 'yhd_notice',
      'options' => NULL,
    ),
    '_widget_588' => 
    array (
      'name' => 'sales_list',
      'options' => NULL,
    ),
    '_widget_865' => 
    array (
      'name' => 'advt',
      'options' => 
      array (
        'style' => 'image',
        'url1' => 'ads/1788270.jpg',
        'link2' => 'http://www.psmoban.com',
        'width1' => '205',
        'height1' => '55',
        'alt' => '',
      ),
    ),
    '_widget_425' => 
    array (
      'name' => 'advt',
      'options' => 
      array (
        'style' => 'image',
        'url1' => 'ads/2021918.jpg',
        'link2' => 'http://www.psmoban.com',
        'width1' => '980',
        'height1' => '60',
        'alt' => '',
      ),
    ),
    '_widget_351' => 
    array (
      'name' => 'yhd_goodslist',
      'options' => 
      array (
        'model_name' => 'ʳƷ����',
        'keyword_list' => '��ʦ�� ������ ��� ǢǢ ���� �ɿڿ��� ��ԣ ���� ������ ������',
        'ad1_image_url' => 'data/files/mall/template/201107221542311948.jpg',
        'ad1_link_url' => 'http://www.psmoban.com',
        'img_recom_id' => '15',
        'img_cate_id' => 0,
        'ad2_image_url' => 'data/files/mall/template/201107221542315274.jpg',
        'ad2_link_url' => 'http://www.psmoban.com',
        'ad3_image_url' => 'data/files/mall/template/201107221542316595.jpg',
        'ad3_link_url' => 'http://www.psmoban.com',
        'ad4_image_url' => 'data/files/mall/template/201107221542315339.jpg',
        'ad4_link_url' => 'http://www.psmoban.com',
      ),
    ),
    '_widget_633' => 
    array (
      'name' => 'yhd_goodslist',
      'options' => 
      array (
        'model_name' => '���ݻ���',
        'keyword_list' => 'ŷ���� ����˿ ������ ���� ���˱��� ���汦 �����׶� �ѽ�ʿ ������ �շ�',
        'ad1_image_url' => 'data/files/mall/template/201107221544393150.jpg',
        'ad1_link_url' => 'http://www.psmoban.com',
        'img_recom_id' => '-100',
        'img_cate_id' => '21',
        'ad2_image_url' => 'data/files/mall/template/201107221544395952.jpg',
        'ad2_link_url' => 'http://www.psmoban.com',
        'ad3_image_url' => 'data/files/mall/template/201107221544399639.jpg',
        'ad3_link_url' => 'http://www.psmoban.com',
        'ad4_image_url' => 'data/files/mall/template/201107221544393360.jpg',
        'ad4_link_url' => 'http://www.psmoban.com',
      ),
    ),
    '_widget_582' => 
    array (
      'name' => 'advt',
      'options' => 
      array (
        'style' => 'image',
        'url1' => 'ads/1970875.jpg',
        'link2' => 'http://www.psmoban.com',
        'width1' => '980',
        'height1' => '60',
        'alt' => '',
      ),
    ),
    '_widget_797' => 
    array (
      'name' => 'yhd_goodslist',
      'options' => 
      array (
        'model_name' => '�������',
        'keyword_list' => '��¶ ������ �ֿ��ֿ� ��� ���� ��� ���� ��� �ղ��� ���˴�',
        'ad1_image_url' => 'data/files/mall/template/201107181252508554.jpg',
        'ad1_link_url' => 'http://www.psmoban.com',
        'img_recom_id' => '-100',
        'img_cate_id' => '21',
        'ad2_image_url' => 'data/files/mall/template/201107181252505165.jpg',
        'ad2_link_url' => 'http://www.psmoban.com',
        'ad3_image_url' => 'data/files/mall/template/201107181252501309.jpg',
        'ad3_link_url' => 'http://www.psmoban.com',
        'ad4_image_url' => 'data/files/mall/template/201107181252508515.jpg',
        'ad4_link_url' => 'http://www.psmoban.com',
      ),
    ),
    '_widget_781' => 
    array (
      'name' => 'yhd_goodslist',
      'options' => 
      array (
        'model_name' => '�Ҿ�',
        'keyword_list' => '��ʿ��������Wenger ��ƥ�� С���� CASIO ��˯�� Napolex ̩�� ˫è Hanes���� ��ʿ��',
        'ad1_image_url' => 'data/files/mall/template/201107181347107629.jpg',
        'ad1_link_url' => 'http://www.psmoban.com',
        'img_recom_id' => '15',
        'img_cate_id' => 0,
        'ad2_image_url' => 'data/files/mall/template/201107181347101430.jpg',
        'ad2_link_url' => 'http://www.psmoban.com',
        'ad3_image_url' => 'data/files/mall/template/201107181347103088.jpg',
        'ad3_link_url' => 'http://www.psmoban.com',
        'ad4_image_url' => 'data/files/mall/template/201107181347101808.jpg',
        'ad4_link_url' => 'http://www.psmoban.com',
      ),
    ),
    '_widget_947' => 
    array (
      'name' => 'advt',
      'options' => 
      array (
        'style' => 'image',
        'url1' => 'ads/1981496.jpg',
        'link2' => 'http://www.psmoban.com',
        'width1' => '980',
        'height1' => '60',
        'alt' => '',
      ),
    ),
    '_widget_943' => 
    array (
      'name' => 'yhd_goodslist',
      'options' => 
      array (
        'model_name' => '����',
        'keyword_list' => 'HP ���� ���� �޼� ŵ���� ƻ�� ���� ���� ��ţ ����',
        'ad1_image_url' => 'data/files/mall/template/201107221549591363.jpg',
        'ad1_link_url' => 'http://www.psmoban.com',
        'img_recom_id' => '15',
        'img_cate_id' => 0,
        'ad2_image_url' => 'data/files/mall/template/201107221549596114.jpg',
        'ad2_link_url' => 'http://www.psmoban.com',
        'ad3_image_url' => 'data/files/mall/template/201107221549594286.jpg',
        'ad3_link_url' => 'http://www.psmoban.com',
        'ad4_image_url' => 'data/files/mall/template/201107221549596517.jpg',
        'ad4_link_url' => 'http://www.psmoban.com',
      ),
    ),
    '_widget_292' => 
    array (
      'name' => 'yhd_goodslist',
      'options' => 
      array (
        'model_name' => '���',
        'keyword_list' => '��� �������汾 С��� ���� ��֮�� ���ν�� �ָ� ���� LALABABY �ű� ',
        'ad1_image_url' => 'data/files/mall/template/201107230151234286.jpg',
        'ad1_link_url' => 'http://www.psmoban.com',
        'img_recom_id' => '-100',
        'img_cate_id' => '21',
        'ad2_image_url' => 'data/files/mall/template/201107230151234745.jpg',
        'ad2_link_url' => 'http://www.psmoban.com',
        'ad3_image_url' => 'data/files/mall/template/201107230151238006.jpg',
        'ad3_link_url' => 'http://www.psmoban.com',
        'ad4_image_url' => 'data/files/mall/template/201107230151236178.jpg',
        'ad4_link_url' => 'http://www.psmoban.com',
      ),
    ),
    '_widget_846' => 
    array (
      'name' => 'advt',
      'options' => 
      array (
        'style' => 'image',
        'url1' => 'ads/1988108.jpg',
        'link2' => 'http://www.psmoban.com',
        'width1' => '980',
        'height1' => '60',
        'alt' => '',
      ),
    ),
    '_widget_246' => 
    array (
      'name' => 'yhd_goodslist',
      'options' => 
      array (
        'model_name' => '��װЬñ',
        'keyword_list' => '��ε�� ���� ��ʨ ������ ����˫�� ����ū OLOMOŷ��ŵ ɭ�� ���� PARGO���',
        'ad1_image_url' => 'data/files/mall/template/201107230153144871.jpg',
        'ad1_link_url' => 'http://www.psmoban.com',
        'img_recom_id' => '15',
        'img_cate_id' => 0,
        'ad2_image_url' => 'data/files/mall/template/201107230153142730.jpg',
        'ad2_link_url' => 'http://www.psmoban.com',
        'ad3_image_url' => 'data/files/mall/template/201107230153146417.jpg',
        'ad3_link_url' => 'http://www.psmoban.com',
        'ad4_image_url' => 'data/files/mall/template/201107230153145596.jpg',
        'ad4_link_url' => 'http://www.psmoban.com',
      ),
    ),
    '_widget_324' => 
    array (
      'name' => 'yhd_goodslist',
      'options' => 
      array (
        'model_name' => 'Ӫ������',
        'keyword_list' => '��A ������ ���� ������ ������ ��ͨ �ƴ� ���� �ƶ��� ����Դ',
        'ad1_image_url' => 'data/files/mall/template/201107230155023243.jpg',
        'ad1_link_url' => 'http://www.psmoban.com',
        'img_recom_id' => '-100',
        'img_cate_id' => '21',
        'ad2_image_url' => 'data/files/mall/template/201107230155022559.jpg',
        'ad2_link_url' => 'http://www.psmoban.com',
        'ad3_image_url' => 'data/files/mall/template/201107230155027704.jpg',
        'ad3_link_url' => 'http://www.psmoban.com',
        'ad4_image_url' => 'data/files/mall/template/201107230155023847.jpg',
        'ad4_link_url' => 'http://www.psmoban.com',
      ),
    ),
    '_widget_941' => 
    array (
      'name' => 'yhd_goodslist',
      'options' => 
      array (
        'model_name' => '�칫��Ʒ',
        'keyword_list' => '���� �״� ��� ���� ���� ���㶫 Double A ���� �ɿ� �����',
        'ad1_image_url' => 'data/files/mall/template/201107230157244723.jpg',
        'ad1_link_url' => 'http://www.psmoban.com',
        'img_recom_id' => '15',
        'img_cate_id' => 0,
        'ad2_image_url' => 'data/files/mall/template/201107230157249554.jpg',
        'ad2_link_url' => 'http://www.psmoban.com',
        'ad3_image_url' => 'data/files/mall/template/201107230157248556.jpg',
        'ad3_link_url' => 'http://www.psmoban.com',
        'ad4_image_url' => 'data/files/mall/template/201107230157248185.jpg',
        'ad4_link_url' => 'http://www.psmoban.com',
      ),
    ),
    '_widget_492' => 
    array (
      'name' => 'yhd_brand',
      'options' => NULL,
    ),
  ),
  'config' => 
  array (
    'top_left' => 
    array (
      0 => '_widget_847',
      1 => '_widget_344',
    ),
    'ads' => 
    array (
      0 => '_widget_432',
    ),
    'cycle_image' => 
    array (
      0 => '_widget_746',
      1 => '_widget_936',
      2 => '_widget_760',
    ),
    'sales' => 
    array (
      0 => '_widget_217',
      1 => '_widget_607',
      2 => '_widget_588',
      3 => '_widget_865',
    ),
    'banner' => 
    array (
      0 => '_widget_425',
      1 => '_widget_351',
      2 => '_widget_633',
      3 => '_widget_582',
      4 => '_widget_797',
      5 => '_widget_781',
      6 => '_widget_947',
      7 => '_widget_943',
      8 => '_widget_292',
      9 => '_widget_846',
      10 => '_widget_246',
      11 => '_widget_324',
      12 => '_widget_941',
      13 => '_widget_492',
    ),
  ),
);

?>