<?php

return array (
  'widgets' => 
  array (
    '_widget_209' => 
    array (
      'name' => 'advt',
      'options' => 
      array (
        'style' => 'image',
        'url1' => 'ads/1988108.jpg',
        'link2' => 'http://www.psmoban.com',
        'width1' => '980',
        'height1' => '60',
        'alt' => '',
      ),
    ),
    '_widget_126' => 
    array (
      'name' => 'brand',
      'options' => NULL,
    ),
    '_widget_318' => 
    array (
      'name' => 'recommended_store',
      'options' => NULL,
    ),
    '_widget_587' => 
    array (
      'name' => 'sales_list',
      'options' => NULL,
    ),
  ),
  'config' => 
  array (
    'banner1' => 
    array (
      0 => '_widget_209',
    ),
    'right' => 
    array (
      0 => '_widget_126',
      1 => '_widget_318',
      2 => '_widget_587',
    ),
  ),
);

?>