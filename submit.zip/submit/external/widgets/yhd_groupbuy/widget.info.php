<?php

return array(
    'name'      => 'yhd_groupbuy',
    'display_name'  => 'yhd-�Ź��Ҽ�',
    'author'    => 'psmoban',
    'website'   => 'http://www.psmoban.com',
    'version'   => '1.0',
    'desc'      => '��ʾ�Ƽ����Ź��',
    'configurable'  => true,
);

?>