<?php

return array(
    'name'      => 'yhd_category',
    'display_name'  => 'yhd-��Ʒ����',
    'author'    => 'psmoban',
    'website'   => 'http://shop59572754.taobao.com',
    'version'   => '1.0',
    'desc'      => '��Ʒ����',
    'configurable'  => false,
);

?>