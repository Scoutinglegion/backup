<?php

return array(
    'name'      => 'image_ad',
    'display_name'  => 'ͼƬ���',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '��ʾһ��ͼƬ���',
    'configurable'  => true,
);

?>