<?php

return array(
    'name'      => 'yhd_login',
    'display_name'  => 'yhd-ע��ͼ��˰�ť',
    'author'    => 'qq:332105640',
    'website'   => 'http://www.psmoban.com',
    'version'   => '1.0',
    'desc'      => 'չʾע��͵�½��ť',
);

?>