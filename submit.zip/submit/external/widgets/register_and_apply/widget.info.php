<?php

return array(
    'name'      => 'register_and_apply',
    'display_name'  => 'ע��ͼ��˰�ť',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => 'չʾע��ͼ��˰�ť',
);

?>